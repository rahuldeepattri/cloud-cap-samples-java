sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("orders.Component", {
    metadata:{ manifest:'json' }
}))
