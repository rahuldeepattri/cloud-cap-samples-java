package cds.gen.adminservice;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import java.lang.Boolean;
import java.lang.String;

/**
 * Add an entity to replicate external address data for quick access,
 * e.g. when displaying lists of orders.
 */
@CdsName("AdminService.Addresses")
public interface Addresses_ extends StructuredType<Addresses_> {
  String CDS_NAME = "AdminService.Addresses";

  ElementRef<String> ID();

  ElementRef<String> businessPartner();

  ElementRef<String> country();

  ElementRef<String> city();

  ElementRef<String> postalCode();

  ElementRef<String> street();

  ElementRef<String> houseNumber();

  ElementRef<Boolean> tombstone();
}
