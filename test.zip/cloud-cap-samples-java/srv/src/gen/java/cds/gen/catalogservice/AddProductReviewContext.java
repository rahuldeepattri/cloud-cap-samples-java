package cds.gen.catalogservice;

import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.EventContext;
import com.sap.cds.services.EventName;
import java.lang.Integer;
import java.lang.String;

@EventName("addProductReview")
public interface AddProductReviewContext extends EventContext {
  String RATING = "rating";

  String TITLE = "title";

  String TEXT = "text";

  String CDS_NAME = "addProductReview";

  Integer getRating();

  void setRating(Integer rating);

  String getTitle();

  void setTitle(String title);

  String getText();

  void setText(String text);

  CqnSelect getCqn();

  void setCqn(CqnSelect select);

  static AddProductReviewContext create() {
    return EventContext.create(AddProductReviewContext.class, "CatalogService.Products");
  }

  void setResult(ProductReviews result);

  ProductReviews getResult();

  static AddProductReviewContext create(String entityName) {
    return EventContext.create(AddProductReviewContext.class, entityName);
  }
}
