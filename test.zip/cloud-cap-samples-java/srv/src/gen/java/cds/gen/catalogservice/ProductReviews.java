package cds.gen.catalogservice;

import com.sap.cds.CdsData;
import com.sap.cds.Struct;
import com.sap.cds.ql.CdsName;
import java.lang.Integer;
import java.lang.String;
import java.time.Instant;
import java.util.Map;

@CdsName("CatalogService.ProductReviews")
public interface ProductReviews extends CdsData {
  String ID = "ID";

  String CREATED_AT = "createdAt";

  String CREATED_BY = "createdBy";

  String MODIFIED_AT = "modifiedAt";

  String MODIFIED_BY = "modifiedBy";

  String PRODUCT = "product";

  String PRODUCT_ID = "product_ID";

  String RATING = "rating";

  String TITLE = "title";

  String TEXT = "text";

  @CdsName(ID)
  String getId();

  @CdsName(ID)
  void setId(String id);

  Instant getCreatedAt();

  void setCreatedAt(Instant createdAt);

  /**
   * Canonical user ID
   */
  String getCreatedBy();

  /**
   * Canonical user ID
   */
  void setCreatedBy(String createdBy);

  Instant getModifiedAt();

  void setModifiedAt(Instant modifiedAt);

  /**
   * Canonical user ID
   */
  String getModifiedBy();

  /**
   * Canonical user ID
   */
  void setModifiedBy(String modifiedBy);

  Products getProduct();

  void setProduct(Map<String, ?> product);

  @CdsName(PRODUCT_ID)
  String getProductId();

  @CdsName(PRODUCT_ID)
  void setProductId(String productId);

  Integer getRating();

  void setRating(Integer rating);

  String getTitle();

  void setTitle(String title);

  String getText();

  void setText(String text);

  ProductReviews_ ref();

  static ProductReviews create() {
    return Struct.create(ProductReviews.class);
  }
}
