package cds.gen.catalogservice;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import com.sap.cds.ql.cqn.CqnPredicate;
import java.lang.Integer;
import java.lang.String;
import java.time.Instant;
import java.util.function.Function;

@CdsName("CatalogService.ProductReviews")
public interface ProductReviews_ extends StructuredType<ProductReviews_> {
  String CDS_NAME = "CatalogService.ProductReviews";

  ElementRef<String> ID();

  ElementRef<Instant> createdAt();

  ElementRef<String> createdBy();

  ElementRef<Instant> modifiedAt();

  ElementRef<String> modifiedBy();

  Products_ product();

  Products_ product(Function<Products_, CqnPredicate> filter);

  ElementRef<String> product_ID();

  ElementRef<Integer> rating();

  ElementRef<String> title();

  ElementRef<String> text();
}
