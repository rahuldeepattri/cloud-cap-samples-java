package cds.gen.catalogservice;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import com.sap.cds.ql.cqn.CqnPredicate;
import java.lang.Boolean;
import java.lang.Integer;
import java.lang.String;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.function.Function;

@CdsName("CatalogService.Products")
public interface Products_ extends StructuredType<Products_> {
  String CDS_NAME = "CatalogService.Products";

  ElementRef<String> ID();

  ElementRef<Instant> createdAt();

  ElementRef<Instant> modifiedAt();

  ElementRef<String> title();

  ElementRef<String> descr();

  ElementRef<Integer> stock();

  ElementRef<BigDecimal> price();

  Currencies_ currency();

  Currencies_ currency(Function<Currencies_, CqnPredicate> filter);

  ElementRef<String> currency_code();

  ElementRef<BigDecimal> rating();

  ProductReviews_ reviews();

  ProductReviews_ reviews(Function<ProductReviews_, CqnPredicate> filter);

  ElementRef<Boolean> isReviewable();

  ProductsTexts_ texts();

  ProductsTexts_ texts(Function<ProductsTexts_, CqnPredicate> filter);

  ProductsTexts_ localized();

  ProductsTexts_ localized(Function<ProductsTexts_, CqnPredicate> filter);
}
