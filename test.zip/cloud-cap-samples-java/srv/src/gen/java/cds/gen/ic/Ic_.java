package cds.gen.ic;

import com.sap.cds.ql.CdsName;
import java.lang.Class;
import java.lang.String;

@CdsName("ic")
public interface Ic_ {
  String CDS_NAME = "ic";

  Class<ProductsTexts_> PRODUCTS_TEXTS = ProductsTexts_.class;

  Class<Products_> PRODUCTS = Products_.class;

  Class<ProductReviews_> PRODUCT_REVIEWS = ProductReviews_.class;
}
