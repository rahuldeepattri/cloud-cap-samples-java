package cds.gen.ic;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import java.lang.String;

@CdsName("ic.Products.texts")
public interface ProductsTexts_ extends StructuredType<ProductsTexts_> {
  String CDS_NAME = "ic.Products.texts";

  ElementRef<String> ID_texts();

  ElementRef<String> locale();

  ElementRef<String> ID();

  ElementRef<String> title();

  ElementRef<String> descr();
}
